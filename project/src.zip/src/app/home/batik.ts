export class Batik {
    batik_id: string;
    province_id: string;
    province_name: string;
    batik_name: string;
    batik_description: string;
    batik_history: string;
    batik_image: string;
    batik_video: string;
    batik_location: string;

    constructor(
        batik_id: string,
        province_id: string,
        province_name: string,
        batik_name: string,
        batik_description: string,
        batik_history: string,
        batik_image: string,
        batik_video: string,
        batik_location: string) {
    }
}
